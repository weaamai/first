document.getElementById('en-button').addEventListener('click', function() {
    document.body.dir = 'ltr';
    document.getElementById('title').textContent = "Dr. Weaam Hamza's Portfolio";
    document.getElementById('about-text').textContent = "A passionate storyteller and educator with extensive experience in cultural storytelling, voiceovers, and graphic design.";
});

document.getElementById('ar-button').addEventListener('click', function() {
    document.body.dir = 'rtl';
    document.getElementById('title').textContent = "ملف التعريف الخاص بالدكتورة وئام حمزة";
    document.getElementById('about-text').textContent = "راوية ومثقفة متمرسة في رواية القصص الثقافية والتمثيل الصوتي وتصميم الرسومات.";
});